package com.klef.jfsd.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.User;
import com.klef.jfsd.springboot.repository.AdminRepository;
import com.klef.jfsd.springboot.repository.UserRepository;

@Service
public class AdminServiceImpl implements AdminService
{
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public List<User> viewallusers() 
	{
		return userRepository.findAll();
		
	}

	@Override
	public String deleteuser(int uid) 
	{
Optional<User> obj =  userRepository.findById(uid);
        
        String msg = null;
        
        if(obj.isPresent())
        {
          User user = obj.get();
          
          userRepository.delete(user);
          
          msg = "User Deleted Successfully";
        }
        else
        {
          msg = "User Not Found";
        }
        
        return msg;
	}


	@Override
	public User viewuserbyid(int uid) 
	{
Optional<User> obj =  userRepository.findById(uid);
        
        if(obj.isPresent())
        {
          User  user = obj.get();
          
          return user;
        }
        else
        {
          return null;
        }
		
	}

	@Override
	public Admin checkadminlogin(String uname, String password)
	{
		return adminRepository.checkadminlogin(uname, password);
		
	}

}
