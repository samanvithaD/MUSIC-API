package com.klef.jfsd.springboot.service;

import com.klef.jfsd.springboot.model.User;

public interface UserService 
{
	public String adduser(User user);
	public String updateuser(User user);
	public User viewuserbyid(int uid);
	public User checkuserlogin(String email,String password);  

}
