package com.klef.jfsd.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.User;
import com.klef.jfsd.springboot.service.AdminService;
import com.klef.jfsd.springboot.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class ClientController 
{
	@Autowired
	private UserService userService;
	
	@Autowired
	private AdminService adminService;
	
	@GetMapping("/")
	public String main()
	{
		return "index";
	}
	
	@GetMapping("index")
  	public ModelAndView index()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("index");
  		return mv;
  	}
    
	
	@GetMapping("userreg")
	public ModelAndView userreg()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("userreg");
		return mv;
	}
	
	@PostMapping("insertuser")
	public ModelAndView insert(HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		
		String msg=null;
		
		try 
		{
			String name=request.getParameter("name");
			 String gender = request.getParameter("gender");
		     String email = request.getParameter("email"); 
		     String password = request.getParameter("password");
		     
		     User user=new User();
		     user.setName(name);
		     user.setGender(gender);
		     user.setEmail(email);
		     user.setPassword(password);
		     
		     msg=userService.adduser(user);
		     
		     mv.setViewName("displaymsg");
		     mv.addObject("message",msg);
		}
		catch(Exception e) 
		{
			msg=e.getMessage();
			mv.setViewName("displayerror");
			mv.addObject("message", msg);
			
		}
		return mv;
	}
	
	@GetMapping("userlogin")
	public ModelAndView userlogin()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("userlogin");
		return mv;
	}
	

    @GetMapping("userhome") // URI & method name can be different 
    public ModelAndView usserhome(HttpServletRequest request) 
    { 
    	HttpSession session = request.getSession();
    	
    	int uid = (int) session.getAttribute("uid");
    	String uname=(String) session.getAttribute("uname");
    	
    
      ModelAndView mv = new ModelAndView(); 
      mv.setViewName("userhome"); 
      
      mv.addObject("uid",uid);
      mv.addObject("uname",uname);
      return mv; 
    } 
    
    @GetMapping("usernavbar") // URI & method name can be different 
    public ModelAndView ussernavbar(HttpServletRequest request) 
    { 
    	HttpSession session = request.getSession();
    	
    	int uid = (int) session.getAttribute("uid");
    	String uname=(String) session.getAttribute("uname");
    	
    
      ModelAndView mv = new ModelAndView(); 
      mv.setViewName("usernavbar"); 
      
      mv.addObject("uid",uid);
      mv.addObject("uname",uname);
      return mv; 
    } 
    
    @PostMapping("checkuserlogin")
    public ModelAndView checkuserlogin(HttpServletRequest request)
    {
      ModelAndView mv = new ModelAndView();
      
      String email = request.getParameter("email");
      String password = request.getParameter("password");
      
        User user = userService.checkuserlogin(email, password);
        
        if(user!=null)
        {
        	HttpSession session=request.getSession();
            session.setAttribute("uid", user.getId()); //eid is a session variable
            session.setAttribute("uname", user.getName()); ////ename is a session variable

          mv.setViewName("index");
        }
        else
        {
          mv.setViewName("userlogin");
          mv.addObject("message", "Login Failed");
        }
        
        return mv;
    }
    
    
    @GetMapping("adminlogin") 
    public ModelAndView adminlogin() 
    { 
      ModelAndView mv = new ModelAndView(); 
      mv.setViewName("adminlogin"); 
      return mv; 
    } 
    
    @GetMapping("musicplayer1") 
    public ModelAndView musicplayer1() 
    { 
      ModelAndView mv = new ModelAndView(); 
      mv.setViewName("musicplayer1"); 
      return mv; 
    } 
    
    @PostMapping("checkadminlogin")
    public ModelAndView checkadminlogin(HttpServletRequest request)
    {
    	ModelAndView mv=new ModelAndView();
    	
    	String uname=request.getParameter("uname");
    	String pwd=request.getParameter("pwd");
    	Admin a=adminService.checkadminlogin(uname, pwd);
    	
    	if(a!=null)
    	{
    		HttpSession session=request.getSession();
            session.setAttribute("uid",a.getId()); //eid is a session variable
            session.setAttribute("uname", a.getUsername());
    		mv.setViewName("index");
    	}
    	else
    	{
    		mv.setViewName("adminlogin");
    		mv.addObject("message", "Login Failed");
    	}
    	
    	return mv;
    }
    
    @GetMapping("viewallusers")
    public ModelAndView viewallusers() {
    	ModelAndView mv=new ModelAndView();
    	mv.setViewName("viewallusers");
    	
    	List<User> userlist=adminService.viewallusers();
    	mv.addObject("userdata",userlist);
    	
    	return mv;
    	
    }
    
    @GetMapping("adminhome") // URI & method name can be different 
    public ModelAndView adminhome(HttpServletRequest request) 
    { 
    	HttpSession session = request.getSession();
    	
    	int uid = (int) session.getAttribute("uid");
    	String uname=(String) session.getAttribute("uname");
    	
    
      ModelAndView mv = new ModelAndView(); 
      mv.setViewName("adminhome"); 
      
      mv.addObject("uid",uid);
      mv.addObject("uname",uname);
      return mv; 
    }  

    @GetMapping("deleteuser")
    public ModelAndView deleteuser() {
    	ModelAndView mv=new ModelAndView();
    	mv.setViewName("deleteuser");
    	
    	List<User> userlist=adminService.viewallusers();
    	mv.addObject("userdata",userlist);
    	
    	return mv;
    	
    }
    
    @GetMapping("view")
    public ModelAndView viewuserdemo(@RequestParam("id") int uid)
    {
      User user = adminService.viewuserbyid(uid);
      ModelAndView mv = new ModelAndView();
      mv.setViewName("viewuserbyid");
      mv.addObject("user", user);
      return mv;
    }
	

    @GetMapping("delete/{id}")
    public String deleteaction(@PathVariable("id") int uid)
    {
      adminService.deleteuser(uid);
      return "redirect:/deleteuser";
    }
	
    
    @GetMapping("trendingsongs")
	public ModelAndView trendingsongs()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("trendingsongs");
		return mv;
	}
    
    @GetMapping("oldsongs")
  	public ModelAndView oldsongs()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("oldsongs");
  		return mv;
  	}
    
    @GetMapping("partysongs")
  	public ModelAndView partysongs()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("partysongs");
  		return mv;
  	}
    
    @GetMapping("dancesongs")
  	public ModelAndView dancesongs()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("dancesongs");
  		return mv;
  	}
    
    @GetMapping("bollywoodsongs")
  	public ModelAndView bollywoodsongs()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("bollywoodsongs");
  		return mv;
  	}
    
    @GetMapping("melodies")
  	public ModelAndView melodies()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("melodies");
  		return mv;
  	}
    
    @GetMapping("rbj")
  	public ModelAndView rbj()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("rbj");
  		return mv;
  	}
    
    @GetMapping("bhediya")
  	public ModelAndView bhediya()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("bhediya");
  		return mv;
  	}
    
    @GetMapping("jawan")
  	public ModelAndView jawan()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("jawan");
  		return mv;
  	}
    
    @GetMapping("kalank")
  	public ModelAndView kalank()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("kalank");
  		return mv;
  	}
    
    @GetMapping("shershaah")
  	public ModelAndView shershaah()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("shershaah");
  		return mv;
  	}
    
    @GetMapping("mission-raniganj")
  	public ModelAndView missionraniganj()
  	{
  		ModelAndView mv=new ModelAndView();
  		mv.setViewName("mission-raniganj");
  		return mv;
  	}




}
