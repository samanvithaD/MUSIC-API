package com.klef.jfsd.springboot.service;

import java.util.List;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.User;

public interface AdminService 
{
	public List<User> viewallusers();
	public String deleteuser(int uid);
	public User viewuserbyid(int uid);
	
	public Admin checkadminlogin(String uname,String password);

}
